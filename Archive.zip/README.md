# Discord Bot Boilerplate
Starting code to help you get your bot going. Comes with a rudimentary command handler, and SQL support with Sequelize.

## Command Handler
Commands go in the `commands` folder, supports aliases.
